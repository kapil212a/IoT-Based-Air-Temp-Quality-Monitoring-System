
#include <Wire.h>
#include <DHT.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define DHT_PIN 4
#define DHT_TYPE DHT22
#define MQ135_PIN 34

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

DHT dht(DHT_PIN, DHT_TYPE);

Adafruit_SSD1306 display(
  SCREEN_WIDTH,
  SCREEN_HEIGHT,
  &Wire,
  -1
);

void setup() {
  Serial.begin(115200);

  dht.begin();

  // Initialize I2C with ESP32 pins
  Wire.begin(21, 22);

  // Initialize OLED at address 0x3C
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("OLED initialization failed!");
    while (true) {
      delay(100);
    }
  }

  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("Air Quality Monitor");
  display.println("OLED Initialized!");
  display.display();

  delay(1500);
}

void loop() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  int airValue = analogRead(MQ135_PIN);

  String status;

  if (airValue < 1200) {
    status = "GOOD";
  } else if (airValue < 2500) {
    status = "MODERATE";
  } else {
    status = "POOR";
  }

  // Display readings on OLED
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setTextSize(1);
  display.setCursor(0, 0);

  display.println("AIR QUALITY MONITOR");
  display.println("--------------------");

  display.print("Temp: ");
  if (isnan(temperature)) {
    display.println("Error");
  } else {
    display.print(temperature, 1);
    display.println(" C");
  }

  display.print("Humidity: ");
  if (isnan(humidity)) {
    display.println("Error");
  } else {
    display.print(humidity, 1);
    display.println(" %");
  }

  display.print("Air Value: ");
  display.println(airValue);

  display.print("Status: ");
  display.println(status);

  display.display();

  // Print readings to Serial Monitor
  Serial.print("Temperature: ");
  Serial.println(temperature);

  Serial.print("Humidity: ");
  Serial.println(humidity);

  Serial.print("Air Value: ");
  Serial.println(airValue);

  Serial.print("Status: ");
  Serial.println(status);

  Serial.println("--------------------");

  delay(2000);
}
